// extension.js
// Linter minimal pour REX-SL :
//  - detecte les point-virgules ';' probablement manquants (heuristique
//    "une instruction par ligne", qui est la convention utilisee dans
//    100% du code REX-SL reel malgre le fait que le compilateur decoupe
//    techniquement sur ';' sans tenir compte des retours a la ligne)
//  - detecte les strings jamais fermees (guillemet manquant), qui sont
//    une vraie erreur fatale du compilateur REX-SL (exception REX_SL
//    "string non terminee")
//
// Ce linter est volontairement simple (pas un vrai parseur REX-SL) : il
// rejoue la meme logique de scan caractere-par-caractere que le lexer
// Python (respect des commentaires '#' et des strings "..."/'...', y
// compris l'echappement '\'), afin de rester coherent avec le vrai
// compilateur plutot que de deviner.

const vscode = require("vscode");

let diagnosticCollection;

/**
 * Analyse un document REX-SL et retourne la liste des diagnostics.
 */
function lintDocument(doc) {
    const diagnostics = [];
    const text = doc.getText();
    const length = text.length;

    let pos = 0;
    let inString = false;
    let quoteChar = null;
    let stringStartOffset = -1;

    // ---- 1) chaines jamais fermees --------------------------------
    // (scan global, insensible aux lignes, comme le vrai lexer)
    while (pos < length) {
        const char = text[pos];

        if (inString) {
            if (char === "\\" && pos + 1 < length) {
                pos += 2;
                continue;
            }
            if (char === quoteChar) {
                inString = false;
                stringStartOffset = -1;
            }
            pos += 1;
            continue;
        }

        if (char === "#") {
            while (pos < length && text[pos] !== "\n") pos += 1;
            continue;
        }

        if (char === '"' || char === "'") {
            inString = true;
            quoteChar = char;
            stringStartOffset = pos;
            pos += 1;
            continue;
        }

        pos += 1;
    }

    if (inString && stringStartOffset >= 0) {
        const startPos = doc.positionAt(stringStartOffset);
        const endPos = doc.positionAt(Math.min(stringStartOffset + 1, length));
        const diag = new vscode.Diagnostic(
            new vscode.Range(startPos, endPos),
            `string non terminee : le guillemet ${quoteChar} ouvert ici n'est jamais referme.`,
            vscode.DiagnosticSeverity.Error
        );
        diag.source = "rexsl";
        diagnostics.push(diag);
    }

    // ---- 2) point-virgule probablement manquant, ligne par ligne --
    // Convention REX-SL : une instruction par ligne, terminee par ';'.
    // On tolere : lignes vides, lignes 100% commentaire, lignes qui ne
    // sont que la suite d'une string ouverte sur une ligne precedente,
    // et la toute derniere ligne non vide du fichier (le compilateur
    // REX-SL accepte l'absence de ';' final en fin de fichier).
    let scanPos = 0;
    let insideMultilineString = false;
    let mlQuoteChar = null;
    const lineCount = doc.lineCount;

    // pre-calcule l'index de la derniere ligne non vide/non-commentaire
    let lastMeaningfulLine = -1;
    for (let i = lineCount - 1; i >= 0; i--) {
        const raw = doc.lineAt(i).text;
        const trimmed = raw.trim();
        if (trimmed !== "" && !trimmed.startsWith("#")) {
            lastMeaningfulLine = i;
            break;
        }
    }

    for (let lineIndex = 0; lineIndex < lineCount; lineIndex++) {
        const lineText = doc.lineAt(lineIndex).text;
        let codeOnLine = "";
        let sawAnyContent = insideMultilineString;
        let charPos = 0;

        while (charPos < lineText.length) {
            const char = lineText[charPos];

            if (insideMultilineString) {
                if (char === "\\" && charPos + 1 < lineText.length) {
                    charPos += 2;
                    continue;
                }
                if (char === mlQuoteChar) {
                    insideMultilineString = false;
                }
                charPos += 1;
                continue;
            }

            if (char === "#") {
                break; // reste de la ligne = commentaire, ignore
            }

            if (char === '"' || char === "'") {
                sawAnyContent = true;
                const quote = char;
                charPos += 1;
                let closed = false;
                while (charPos < lineText.length) {
                    const c = lineText[charPos];
                    if (c === "\\" && charPos + 1 < lineText.length) {
                        charPos += 2;
                        continue;
                    }
                    if (c === quote) {
                        closed = true;
                        charPos += 1;
                        break;
                    }
                    charPos += 1;
                }
                if (!closed) {
                    // la string continue sur la/les ligne(s) suivante(s)
                    insideMultilineString = true;
                    mlQuoteChar = quote;
                }
                codeOnLine += "x"; // placeholder neutre pour le contenu string
                continue;
            }

            codeOnLine += char;
            if (!/\s/.test(char)) sawAnyContent = true;
            charPos += 1;
        }

        const trimmedCode = codeOnLine.trim();
        if (!sawAnyContent) continue;
        if (trimmedCode === "") continue; // ligne 100% commentaire (ou vide)
        if (insideMultilineString) continue; // la string n'est pas encore fermee, pas de ';' attendu ici
        if (trimmedCode.endsWith(";")) continue; // OK
        if (lineIndex === lastMeaningfulLine) continue; // derniere ligne : tolere par le compilateur

        const range = new vscode.Range(
            new vscode.Position(lineIndex, lineText.length),
            new vscode.Position(lineIndex, lineText.length)
        );
        const diag = new vscode.Diagnostic(
            range,
            "point-virgule ';' probablement manquant en fin d'instruction.",
            vscode.DiagnosticSeverity.Warning
        );
        diag.source = "rexsl";
        diag.code = "missing-semicolon";
        diagnostics.push(diag);
    }

    return diagnostics;
}

function refreshDiagnostics(doc) {
    if (doc.languageId !== "rexsl") return;
    diagnosticCollection.set(doc.uri, lintDocument(doc));
}

function activate(context) {
    diagnosticCollection = vscode.languages.createDiagnosticCollection("rexsl");
    context.subscriptions.push(diagnosticCollection);

    if (vscode.window.activeTextEditor) {
        refreshDiagnostics(vscode.window.activeTextEditor.document);
    }

    context.subscriptions.push(
        vscode.workspace.onDidOpenTextDocument(refreshDiagnostics),
        vscode.workspace.onDidChangeTextDocument((e) => refreshDiagnostics(e.document)),
        vscode.workspace.onDidSaveTextDocument(refreshDiagnostics),
        vscode.workspace.onDidCloseTextDocument((doc) => diagnosticCollection.delete(doc.uri))
    );

    for (const doc of vscode.workspace.textDocuments) {
        refreshDiagnostics(doc);
    }
}

function deactivate() {
    if (diagnosticCollection) diagnosticCollection.clear();
}

module.exports = { activate, deactivate };
