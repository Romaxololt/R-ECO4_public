# REX>
# exemple de test pour la coloration syntaxique REX

#* bloc de commentaire
   sur plusieurs lignes *#

var x = 5
var number y = 10

var name = "Ada"
var age = 36
show(f"{name} a {age} ans")

if x > 3 and (y < 20 or not x == y):
    show("x est grand", y, sep=", ")
elif x == y:
    show("egal")
else:
    show(x, end="")

while x < 10:
    x = x + 1

for i in range(0, 10, 2):
    show(i)

repeat 3:
    show("boucle")

func add_one(number n):
    var result = n + 1
    return result

var total = add_one(x)
show(total)

var items = [1, 2, 3]
var pair = (x, y)
var uniq = {1, 2, 2, 3}
var info = {"cle": 1, "autre": 2}

label start;
if x < 0:
    go start;

var content = read("data.txt")
write("out.txt", content)
