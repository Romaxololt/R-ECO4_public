# REX>
# exemple de test pour la coloration syntaxique REX

#* bloc de commentaire
   sur plusieurs lignes *#

var x = 5
var number y = 10

var name = "Ada"
var age = 36
show(f"{name} a {age} ans")

if x > 3 and (y < 20 or not x == y):
    show("x est grand", y, sep=", ")
elif x == y:
    show("egal")
else:
    show(x, end="")

while x < 10:
    x = x + 1

for i in range(0, 10, 2):
    show(i)

repeat 3:
    show("boucle")

func add_one(number n):
    var result = n + 1
    return result

var total = add_one(x)
show(total)

var items = [1, 2, 3]
var pair = (x, y)
var uniq = {1, 2, 2, 3}
var info = {"cle": 1, "autre": 2}

label start;
if x < 0:
    go start;

var content = read("data.txt")
write("out.txt", content)
appendfile("out.txt", "\nfin")

assert x >= 0, "x doit etre positif"

match x:
    case 1:
        show("un")
    case 2:
        show("deux")
    default:
        show("autre")

try:
    var risque = add_one(x)
except as e:
    show(f"erreur: {e}")
finally:
    show("termine")

class Compteur:
    def __init__(self, number start):
        self.val = start

    def incrementer(self):
        self.val = self.val + 1

    def get(self) -> number:
        return self.val

var c = Compteur(0)
c.incrementer()
show(c.get())
